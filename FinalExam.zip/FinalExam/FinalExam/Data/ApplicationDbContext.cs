﻿using System;
using System.Collections.Generic;
using System.Text;
using FinalExam.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace FinalExam.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {

        public DbSet<Divisions> Divisins { get; set; }
        public DbSet<Teams> Teams { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}
